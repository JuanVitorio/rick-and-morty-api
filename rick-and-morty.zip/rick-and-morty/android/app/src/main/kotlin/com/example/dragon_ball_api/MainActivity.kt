package com.example.dragon_ball_api

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
